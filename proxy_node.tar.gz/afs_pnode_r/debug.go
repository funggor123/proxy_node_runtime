package main

import (
	"fmt"
)

var DEBUG_MSG_ERROR = "(Error) "
var DEBUG_MSG_TRACK = "(Track) "
var debug = true

func print_debug(a ...interface{}) {
	if debug {
		fmt.Println(a)
	}
}
