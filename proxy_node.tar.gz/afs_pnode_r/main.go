package main

import (
	"fmt"
	"os"
	"os/exec"
)

func main() {
	err := readConfig()
	if err != nil {
		return
	}
	print_debug(DEBUG_MSG_TRACK, "Real-time logs locate in /ngrok/bin/ngrokd.log")
	os.Remove("./ngrok/bin/ngrokd.log")
	_, err = runBashComamnd()
	if err != nil {
		return
	}
}

func runBashComamnd() (string, error) {

	var cmd *exec.Cmd
	var commandResult []byte
	var err error

	cmd = exec.Command("./ngrokd", "-log=ngrokd.log", "-domain", config.Host_Domain, "-tunnelAddr", ":"+config.Host_Port, "-portStart", config.Start_Port, "-portEnd", config.End_Port)
	dir, err := os.Getwd()
	if err != nil {
		print_debug(DEBUG_MSG_ERROR, "1", err)
	}
	cmd.Dir = dir + "/ngrok/bin/"
	if commandResult, err = cmd.CombinedOutput(); err != nil {
		fmt.Println(fmt.Sprint(err) + ": " + string(commandResult))
		return "", err
	}
	return string(commandResult), nil
}
