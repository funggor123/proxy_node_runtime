package main

import (
	"encoding/json"
	"os"
)

type Configuration struct {
	Host_Domain string `json:"host_domain" binding:"required"`
	Host_Port   string `json:"port" binding:"required"`
}

var CONFIG_JSON_STRING = "conf.json"
var DEBUG_CLASS = "[read_config]"
var config Configuration

func readConfig() error {
	file, _ := os.Open(CONFIG_JSON_STRING)
	defer file.Close()
	decoder := json.NewDecoder(file)
	configuration := Configuration{}
	err := decoder.Decode(&configuration)
	if err != nil {
		print_debug(DEBUG_MSG_ERROR, "1", err)
		return err
	}
	config = configuration
	return nil
}
