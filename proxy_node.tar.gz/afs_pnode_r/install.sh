#! /bin/bash
echo "Hey, it is going to install proxy node now"
echo "During installation, you need to provide your host ip address"
echo "Are you ready?(y/n)"
read choice
if [ "$choice" = "n" ] ; then
	echo "The installation has been terminated"
	exit 0
fi
echo "OK, lets get start"
echo "Please provde the host address (e.g. 192.168.1.1) of this proxy node, this ip address must be accessable by other proxy client"
read ip
echo "Please provide the host port of this proxy node"
read port
cat <<EOF > conf.json
{
    "host_domain": "${ip}",
    "host_port": "${port}" 
}
EOF
echo "Creating a service for our program"
c_user="$USER"
start_path="$PWD"
cat <<EOF >  /etc/systemd/system/pnode.service
[Unit]
Description=This is the service of proxy node
After=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=${c_user}
WorkingDirectory=${start_path}
ExecStart=${start_path}/main

[Install]
WantedBy=multi-user.target
EOF
echo "Congradualation !! The installation has completed"

